using Microsoft.AspNetCore.Mvc;
using ControlAcademicoMvc.Models;

namespace ControlAcademicoMvc.Controllers
{
    public class EstudianteController : Controller
    {
        private static readonly List<Estudiante> estudiantes = new()
        {
            new Estudiante
            {
                Carne = 2026012,
                Nombre = "Fernando Velasquez",
                Promedio = 91.5
            },
            new Estudiante
            {
                Carne = 2026045,
                Nombre = "Maria Mercedes",
                Promedio = 84.0
            }
        };

        public IActionResult Listar()
        {
            return View(estudiantes);
        }

        [HttpPost]
        public IActionResult Registrar([FromBody] Estudiante nuevo)
        {
            if (nuevo.Carne <= 0 ||
                string.IsNullOrWhiteSpace(nuevo.Nombre))
            {
                return BadRequest(new
                {
                    mensaje = "Datos del estudiante invalidos."
                });
            }

            estudiantes.Add(nuevo);

            return Created(
                $"/Estudiante/Historial/{nuevo.Carne}",
                nuevo
            );
        }
    }
}